import json,sys,os
os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)),"..","sheets"))
L=lambda n:json.load(open(n+".json"))
W={x["id"]:x for x in L("weapons")}; A={x["id"]:x for x in L("armor")}
rules={r["id"]:r for r in L("rules")}; budget=rules["economy"]["start_money"]
bad=[]
for n in ["weapons","armor","hit_zones","bot_loadouts","hooks"]:
    for r in L(n):
        for k,v in r.items():
            if v in ("",None) and not(n=="bot_loadouts" and k in("arms","legs","head","chest")) and not(n=="hooks" and k=="notes"):
                bad.append(f"unfilled: {n}.{r.get('id',r.get('zone'))}.{k}")
zones={z["armor_zone"] for z in L("hit_zones")}
for a in A.values():
    if a["zone"] not in zones: bad.append(f"armor {a['id']}: zone {a['zone']} not in hit_zones")
for b in L("bot_loadouts"):
    if b["weapon"] not in W: bad.append(f"bot {b['id']}: unknown weapon")
    cost=W[b["weapon"]]["price"]; wt=W[b["weapon"]]["weight"]
    for s in("head","chest","arms","legs"):
        if b[s]:
            if b[s] not in A: bad.append(f"bot {b['id']}: unknown armor {b[s]}"); continue
            if A[b[s]]["zone"]!=s: bad.append(f"bot {b['id']}: {b[s]} wrong slot")
            cost+=A[b[s]]["price"]; wt+=A[b[s]]["weight"]
    if cost>budget: bad.append(f"bot {b['id']}: cost {cost} > budget {budget}")
    w=rules["weight"]; sp=max(w["min_speed_mult"],1-max(0,wt-w["free_weight"])*w["slow_per_kg"])
    print(f"bot {b['id']}: cost {cost}/{budget}, weight {wt:.1f}kg, speed x{sp:.2f}")
for h in L("hooks"):
    if h["status"]!="verified": bad.append(f"unverified hook: {h['id']}")
print("\n".join(bad) or "CLEAN")
