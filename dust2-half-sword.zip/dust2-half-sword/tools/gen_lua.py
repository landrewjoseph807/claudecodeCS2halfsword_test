"""Generates generated/loadout_data.lua from the JSON sheets (sheets are the source of truth)."""
import json,os
base=os.path.join(os.path.dirname(os.path.abspath(__file__)),"..")
def lua(v,i=0):
    p="  "*i
    if v is None: return "nil"
    if isinstance(v,bool): return "true" if v else "false"
    if isinstance(v,(int,float)): return repr(v)
    if isinstance(v,str): return json.dumps(v)
    if isinstance(v,list): return "{\n"+"".join(p+"  "+lua(x,i+1)+",\n" for x in v)+p+"}"
    return "{\n"+"".join(f'{p}  {k} = {lua(x,i+1)},\n' for k,x in v.items() if x is not None)+p+"}"
out=["-- GENERATED from sheets/*.json by tools/gen_lua.py. Do not edit by hand.","Data = {}"]
for n in ["weapons","armor","hit_zones","bot_loadouts","rules"]:
    out.append(f"Data.{n} = "+lua(json.load(open(f"{base}/sheets/{n}.json"))))
open(f"{base}/generated/loadout_data.lua","w").write("\n".join(out)+"\n")
print("wrote generated/loadout_data.lua")
